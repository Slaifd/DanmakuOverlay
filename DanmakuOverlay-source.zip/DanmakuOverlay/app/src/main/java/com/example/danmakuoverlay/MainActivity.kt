package com.example.danmakuoverlay

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private var audioUri: Uri? = null
    private var assUri: Uri? = null
    private lateinit var audioLabel: TextView
    private lateinit var assLabel: TextView
    private val pickAudio = 1
    private val pickAss = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(28, 36, 28, 24)
        }
        layout.addView(TextView(this).apply {
            text = "录播悬浮弹幕 · 0.1.0\\n\\n选择同一次录制生成的 M4A 和 ASS 文件。开始后，音频与弹幕按时间轴同步播放。"
            textSize = 18f
        }, match())
        audioLabel = label("尚未选择音频文件")
        layout.addView(audioLabel, match())
        layout.addView(button("选择 M4A 音频") { choose(pickAudio, "audio/*") }, match())
        assLabel = label("尚未选择 ASS 弹幕文件")
        layout.addView(assLabel, match())
        layout.addView(button("选择 ASS 文件") { choose(pickAss, "*/*") }, match())
        layout.addView(button("开启悬浮窗权限") {
            if (!Settings.canDrawOverlays(this)) {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            } else Toast.makeText(this, "悬浮窗权限已开启", Toast.LENGTH_SHORT).show()
        }, match())
        layout.addView(button("开始播放 + 显示悬浮弹幕") { startPlayback() }, match())
        layout.addView(button("停止播放并关闭弹幕") {
            stopService(Intent(this, PlaybackService::class.java))
        }, match())
        layout.addView(TextView(this).apply {
            text = "\\n说明：首版以亮屏、已授权悬浮窗为目标。悬浮文字覆盖在其他应用上层；如果文件选择器没有显示 ASS，请在文件类型中选“所有文件”。"
            textSize = 14f
        }, match())
        setContentView(layout)
    }

    private fun choose(code: Int, type: String) {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            this.type = type
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION)
        }
        startActivityForResult(intent, code)
    }

    @Deprecated("Deprecated by Android but compatible with broad device range")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try { contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
        if (requestCode == pickAudio) {
            audioUri = uri
            audioLabel.text = "音频：${uri.lastPathSegment ?: uri}"
        } else if (requestCode == pickAss) {
            assUri = uri
            assLabel.text = "弹幕：${uri.lastPathSegment ?: uri}"
        }
    }

    private fun startPlayback() {
        val a = audioUri
        val s = assUri
        if (a == null || s == null) {
            Toast.makeText(this, "请先选择 M4A 和 ASS 文件", Toast.LENGTH_LONG).show()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "请先开启悬浮窗权限", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        val intent = Intent(this, PlaybackService::class.java).apply {
            action = PlaybackService.ACTION_START
            putExtra(PlaybackService.EXTRA_AUDIO, a.toString())
            putExtra(PlaybackService.EXTRA_ASS, s.toString())
        }
        startForegroundService(intent)
        Toast.makeText(this, "已请求开始播放；请下拉通知栏查看播放状态", Toast.LENGTH_SHORT).show()
    }

    private fun label(value: String) = TextView(this).apply {
        text = value
        textSize = 15f
        setPadding(0, 18, 0, 8)
    }
    private fun button(value: String, action: () -> Unit) = Button(this).apply {
        text = value
        setOnClickListener { action() }
    }
    private fun match() = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
}
