package com.example.danmakuoverlay

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.TextView
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.math.roundToInt

class PlaybackService : Service() {
    companion object {
        const val ACTION_START = "com.example.danmakuoverlay.START"
        const val EXTRA_AUDIO = "audio_uri"
        const val EXTRA_ASS = "ass_uri"
        private const val CHANNEL_ID = "danmaku_playback"
        private const val NOTIFICATION_ID = 43
    }

    private data class Cue(val start: Long, val end: Long, val text: String, val y: Int, val xStart: Int, val xEnd: Int)
    private var player: MediaPlayer? = null
    private var windowManager: WindowManager? = null
    private var overlay: FrameLayout? = null
    private var cues: List<Cue> = emptyList()
    private val active = mutableMapOf<Int, TextView>()
    private val handler = Handler(Looper.getMainLooper())
    private var screenWidth = 1080

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action != ACTION_START) {
            stopSelf()
            return START_NOT_STICKY
        }
        val audio = intent.getStringExtra(EXTRA_AUDIO)?.let(Uri::parse)
        val ass = intent.getStringExtra(EXTRA_ASS)?.let(Uri::parse)
        if (audio == null || ass == null) { stopSelf(); return START_NOT_STICKY }
        stopPlayback()
        createChannel()
        startForeground(NOTIFICATION_ID, notification("正在准备音频与弹幕"))
        try {
            cues = parseAss(ass)
            screenWidth = resources.displayMetrics.widthPixels
            windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
            overlay = FrameLayout(this).apply { setBackgroundColor(Color.TRANSPARENT) }
            if (Settings.canDrawOverlays(this)) {
                val params = WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.MATCH_PARENT,
                    if (Build.VERSION.SDK_INT >= 26) WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY else WindowManager.LayoutParams.TYPE_PHONE,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT
                ).apply { gravity = Gravity.TOP or Gravity.START; x = 0; y = 0 }
                windowManager?.addView(overlay, params)
            }
            player = MediaPlayer().apply {
                setDataSource(this@PlaybackService, audio)
                setOnPreparedListener { it.start(); handler.post(tick) }
                setOnCompletionListener { stopSelf() }
                setOnErrorListener { _, _, _ -> stopSelf(); true }
                prepareAsync()
            }
        } catch (_: Exception) {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private val tick = object : Runnable {
        override fun run() {
            val p = player ?: return
            if (!p.isPlaying) { handler.postDelayed(this, 100L); return }
            val time = p.currentPosition.toLong()
            val wanted = cues.indices.filter { time >= cues[it].start && time < cues[it].end }.toSet()
            (active.keys - wanted).toList().forEach { idx ->
                active.remove(idx)?.let { overlay?.removeView(it) }
            }
            wanted.forEach { idx ->
                val cue = cues[idx]
                var tv = active[idx]
                if (tv == null) {
                    tv = TextView(this@PlaybackService).apply {
                        text = cue.text
                        textSize = 18f
                        setTextColor(Color.WHITE)
                        setShadowLayer(3f, 1f, 1f, Color.BLACK)
                        setSingleLine(true)
                    }
                    active[idx] = tv
                    overlay?.addView(tv, FrameLayout.LayoutParams(-2, -2))
                }
                val elapsed = (time - cue.start).toFloat() / (cue.end - cue.start).coerceAtLeast(1)
                val x = (cue.xStart + (cue.xEnd - cue.xStart) * elapsed).roundToInt()
                tv.translationX = x * screenWidth.toFloat() / 1280f
                tv.translationY = cue.y * screenWidth.toFloat() / 1280f
            }
            handler.postDelayed(this, 33L)
        }
    }

    private fun parseAss(uri: Uri): List<Cue> {
        val out = mutableListOf<Cue>()
        contentResolver.openInputStream(uri).use { stream ->
            if (stream == null) return emptyList()
            BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).useLines { lines ->
                lines.forEach { line ->
                    if (!line.startsWith("Dialogue:")) return@forEach
                    val fields = line.substringAfter("Dialogue:").trim().split(',', limit = 10)
                    if (fields.size < 10) return@forEach
                    val start = parseTime(fields[1]) ?: return@forEach
                    val end = parseTime(fields[2]) ?: return@forEach
                    val raw = fields[9]
                    val move = Regex("\\\\move\\((-?\\d+),(-?\\d+),(-?\\d+),(-?\\d+)(?:,\\d+,\\d+)?\\)").find(raw)
                    val x1 = move?.groupValues?.get(1)?.toIntOrNull() ?: 1280
                    val y = move?.groupValues?.get(2)?.toIntOrNull() ?: 88
                    val x2 = move?.groupValues?.get(3)?.toIntOrNull() ?: -340
                    val plain = raw.replace(Regex("\\{[^}]*}"), "").replace("\\\\N", " ").replace("\\\\n", " ").replace("\\\\h", " ")
                    if (plain.isNotBlank() && end > start) out.add(Cue(start, end, plain, y, x1, x2))
                }
            }
        }
        return out.sortedBy { it.start }
    }

    private fun parseTime(value: String): Long? {
        return try {
            val parts = value.trim().split(':')
            val sec = parts.last().toDouble()
            val minutes = parts[parts.size - 2].toLong()
            val hours = parts[parts.size - 3].toLong()
            ((hours * 3600 + minutes * 60) * 1000 + (sec * 1000).toLong())
        } catch (_: Exception) { null }
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "录播弹幕播放", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(message: String): Notification {
        val stopIntent = PendingIntent.getService(this, 9, Intent(this, PlaybackService::class.java), PendingIntent.FLAG_UPDATE_CURRENT or if (Build.VERSION.SDK_INT >= 23) PendingIntent.FLAG_IMMUTABLE else 0)
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL_ID) else Notification.Builder(this)
        return builder.setContentTitle("录播悬浮弹幕").setContentText(message)
            .setSmallIcon(android.R.drawable.ic_media_play)
            .addAction(Notification.Action.Builder(null, "停止", stopIntent).build())
            .setOngoing(true).build()
    }

    private fun stopPlayback() {
        handler.removeCallbacks(tick)
        try { player?.stop() } catch (_: Exception) {}
        player?.release()
        player = null
        active.clear()
        try { overlay?.let { windowManager?.removeView(it) } } catch (_: Exception) {}
        overlay = null
        windowManager = null
    }

    override fun onDestroy() {
        stopPlayback()
        stopForeground(STOP_FOREGROUND_REMOVE)
        super.onDestroy()
    }
}
